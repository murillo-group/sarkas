# Sarkas
A Pure Python Molecular Dynamics package for Non-Ideal Plasmas


Sarkas is a pure-Python Molecular Dynamics (MD) package designed with plasma physics in mind. The
pure-python construction allows users to quickly add their own features to model the systems of
their choosing. 

## Documentation
https://murillo-group.github.io/sarkas/

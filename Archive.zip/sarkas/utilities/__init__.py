"""
Module containing Sarkas utilities classes. Contains Timing, and Input-Output
"""
